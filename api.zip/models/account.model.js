function Account(id, balance) {
  return {
    id: `${id}`,
    balance
  };
}

module.exports = Account;
